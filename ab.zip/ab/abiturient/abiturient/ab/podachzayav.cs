﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace abiturient.ab
{
    public partial class podachzayav : Form
    {
        private string login;

        public podachzayav(string login)
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            mainab ab = new mainab(login);
            this.Hide();
            ab.Show();
        }

        private void podachzayav_Load(object sender, EventArgs e)
        {

        }
        private int userScore;
        private void button1_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(connection.con))
                    {
                        conn.Open();

                        int userId = GetUserIdByUsername(conn, textBox4.Text);
                        if (userId == -1)
                        {
                            MessageBox.Show("Пользователь с указанным именем не найден.");
                            return;
                        }

                        // Запрос для получения суммы баллов
                        string query = "SELECT SUM(Score) AS TotalScore FROM ExamScores WHERE UserID = @UserID";

                        using (SqlCommand command = new SqlCommand(query, conn))
                        {
                            command.Parameters.AddWithValue("@UserID", userId);

                            object result = command.ExecuteScalar();
                            if (result != null && result != DBNull.Value)
                            {
                                // Преобразуем результат в целое число
                                int totalScore = Convert.ToInt32(result);

                                // Устанавливаем значение лейбла
                                label1.Text = $"Ваш общий балл: {totalScore}";
                                userScore = totalScore;
                            }
                            else
                            {
                                // Если сумма баллов равна null или DBNull.Value, выводим сообщение об ошибке
                                MessageBox.Show("Не удалось получить сумму баллов.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}");
                }
            }
        }

        private int GetUserIdByUsername(SqlConnection conn, string username)
        {
            string query = "SELECT UserID FROM Users WHERE Username = @Username";

            using (SqlCommand command = new SqlCommand(query, conn))
            {
                command.Parameters.AddWithValue("@Username", username);

                object result = command.ExecuteScalar();
                if (result != null)
                {
                    return (int)result;
                }

                return -1; // Возвращаем -1, если пользователь не найден
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

            try
            {
                using (SqlConnection conn = new SqlConnection(connection.con))
                {
                    conn.Open();

                    string query = "SELECT * FROM Faculties WHERE MinScore <= @UserScore\r\n";

                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@UserScore", userScore);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            // Очищаем ComboBox перед добавлением новых элементов
                            comboBox1.Items.Clear();

                            while (reader.Read())
                            {
                                comboBox1.Items.Add(reader["FacultyName"].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при получении факультетов: {ex.Message}");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connection.con))
                {
                    conn.Open();

                    int userId = GetUserIdByUsername(conn, textBox4.Text);
                    if (userId == -1)
                    {
                        MessageBox.Show("Пользователь с указанным именем не найден.");
                        return;
                    }

                    int facultyId = GetFacultyIdByName(conn, comboBox1.Text);
                    if (facultyId == -1)
                    {
                        MessageBox.Show("Факультет с указанным именем не найден.");
                        return;
                    }

                    string query = "INSERT INTO Applications (UserID, FacultyID, Accept) VALUES (@UserID, @FacultyID, 0)";

                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);
                        command.Parameters.AddWithValue("@FacultyID", facultyId);

                        command.ExecuteNonQuery();

                        MessageBox.Show("Заявка успешно подана.");
                        
                    }
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при подаче заявки: {ex.Message}");
            }
        }

        private int GetFacultyIdByName(SqlConnection conn, string facultyName)
        {
            string query = "SELECT FacultyID FROM Faculties WHERE FacultyName = @FacultyName";

            using (SqlCommand command = new SqlCommand(query, conn))
            {
                command.Parameters.AddWithValue("@FacultyName", facultyName);

                object result = command.ExecuteScalar();
                if (result != null)
                {
                    return (int)result;
                }

                return -1; // Возвращаем -1, если факультет не найден
            }
        }
    }
}
