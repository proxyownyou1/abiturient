﻿using System;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;
using System.Data;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Threading.Tasks;

namespace abiturient
{
    public partial class reg : Form
    {
        private string verificationCode; // Переменная для хранения двухфакторного кода
        private bool isCodeSent = false;
        private string username;

        public reg()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
          

            // Проверяем, что username не пуст и не содержит пробелов
            if (string.IsNullOrWhiteSpace(username) || username.Contains(" "))
            {
                MessageBox.Show("Введите корректное имя пользователя без пробелов.");
                return;
            }

            // Вставляем данные в таблицу Users
            try
            {
                using (SqlConnection conn = new SqlConnection(connection.con))
                {
                    conn.Open();

                    string query = "INSERT INTO Users (Username) VALUES (@Username)";
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@Username", username);
                     

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Пользователь успешно зарегистрирован. Нажмите кнопку 'Отправить код' для завершения регистрации.");
                        }
                        else
                        {
                            MessageBox.Show("Не удалось выполнить регистрацию.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при регистрации: {ex.Message}");
            }
        }



        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                // Преобразование пароля в массив байт
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password);

                // Вычисление хэша
                byte[] hashBytes = sha256.ComputeHash(passwordBytes);

                // Преобразование хэша в строку
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    builder.Append(hashBytes[i].ToString("x2"));
                }

                return builder.ToString();
            }
        }

        private string GenerateAndSaveVerificationCode(string username)
        {
            try
            {
                // Генерация двухфакторного кода (6-значный код)
                Random random = new Random();
                string verificationCode = random.Next(100000, 999999).ToString();

                // Получение UserID по имени пользователя
                int userId;
                using (SqlConnection conn = new SqlConnection(connection.con))
                {
                    conn.Open();

                    string getUserIdQuery = "SELECT UserID FROM Users WHERE Username = @Username";
                    using (SqlCommand getUserIdCommand = new SqlCommand(getUserIdQuery, conn))
                    {
                        getUserIdCommand.Parameters.AddWithValue("@Username", username);
                        userId = Convert.ToInt32(getUserIdCommand.ExecuteScalar());
                    }
                }

                // Сохранение кода в базе данных в таблицу VerificationCodes
                using (SqlConnection conn = new SqlConnection(connection.con))
                {
                    conn.Open();

                    string query = "INSERT INTO VerificationCodes (UserID, VerificationCode) VALUES (@UserID, @VerificationCode)";
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);
                        command.Parameters.AddWithValue("@VerificationCode", verificationCode);

                        command.ExecuteNonQuery();
                    }
                }

                // Возвращаем сгенерированный код
                return verificationCode;
            }
            catch (Exception ex)
            {
                // Обработка ошибки
                MessageBox.Show($"Ошибка при генерации кода: {ex.Message}");
                return string.Empty;
            }
        }

        private async void SendEmail(string toEmail)
        {
            try
            {
                // Проверка валидности адреса электронной почты
                if (!IsValidEmail(toEmail))
                {
                    MessageBox.Show("Введите корректный адрес электронной почты.");
                    return;
                }

                string fromEmail = "grisha.terentev.228@mail.ru";
                string subject = "Код подтверждения регистрации";
                string body = $"Ваш двухфакторный код для регистрации: {verificationCode}";

                using (SmtpClient smtp = new SmtpClient("smtp.mail.ru"))
                {
                    smtp.Timeout = 10000;
                    smtp.Port = 587;  // Порт 587 для шифрования SSL/TLS
                    smtp.Credentials = new NetworkCredential(fromEmail, "63fNfSwpaq17MFUQxpip");
                    smtp.EnableSsl = true;

                    using (MailMessage message = new MailMessage(fromEmail, toEmail, subject, body))
                    {
                        await smtp.SendMailAsync(message);
                        MessageBox.Show("Письмо успешно отправлено.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при отправке письма: {ex.Message}");
            }
        }



        private void reg_Load(object sender, EventArgs e)
        {

        }

        private async void button2_Click(object sender, EventArgs e)
        {
            string email = textBox3.Text;

            // Проверяем, что почта не пуста
            if (string.IsNullOrWhiteSpace(email))
            {
                MessageBox.Show("Введите корректный адрес электронной почты.");
                return;
            }

            // Генерация и сохранение двухфакторного кода в базе данных
            verificationCode = GenerateAndSaveVerificationCode(textBox1.Text);

            // Асинхронная отправка электронного письма с двухфакторным кодом
            await Task.Run(() => SendEmail(email));

            // Устанавливаем флаг, что код был отправлен
            isCodeSent = true;

            // Делаем TextBox4 доступным для ввода
            textBox4.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string enteredCode = textBox4.Text;
            string username = textBox1.Text; // Получение значения username

            // Проверка введенного кода с сгенерированным
            if (enteredCode != verificationCode)
            {
                MessageBox.Show("Введенный код неверен. Пожалуйста, проверьте код в вашей почте и введите его корректно.");
                return;
            }

            // Вставляем остальные данные в таблицу Users
            try
            {
                using (SqlConnection conn = new SqlConnection(connection.con))
                {
                    conn.Open();

                    string query = "UPDATE Users SET Password = @Password, Email = @Email, IsAdmin = @IsAdmin WHERE Username = @Username";
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@Password", HashPassword(textBox2.Text));
                        command.Parameters.AddWithValue("@Email", textBox3.Text);
                        command.Parameters.AddWithValue("@IsAdmin", (comboBox1.SelectedIndex == 1));

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Регистрация успешно завершена.");
                            auth auth = new auth();
                            auth.Show();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Не удалось выполнить регистрацию.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при регистрации: {ex.Message}");
            }
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var mailAddress = new System.Net.Mail.MailAddress(email);
                return mailAddress.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            main mn = new main();
            this.Hide();
            mn.Show();
        }
    }
}
