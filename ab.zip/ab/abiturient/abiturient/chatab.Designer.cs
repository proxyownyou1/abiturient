﻿namespace abiturient
{
    partial class chatab
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.bConnDiscon = new System.Windows.Forms.Button();
            this.tbUserName = new System.Windows.Forms.TextBox();
            this.lbChat = new System.Windows.Forms.ListBox();
            this.tbMessage = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(150, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Чат";
            // 
            // bConnDiscon
            // 
            this.bConnDiscon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bConnDiscon.FlatAppearance.BorderSize = 0;
            this.bConnDiscon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bConnDiscon.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bConnDiscon.ForeColor = System.Drawing.Color.White;
            this.bConnDiscon.Location = new System.Drawing.Point(1, 51);
            this.bConnDiscon.Name = "bConnDiscon";
            this.bConnDiscon.Size = new System.Drawing.Size(133, 42);
            this.bConnDiscon.TabIndex = 10;
            this.bConnDiscon.Text = "Подключиться";
            this.bConnDiscon.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.bConnDiscon.UseVisualStyleBackColor = true;
            this.bConnDiscon.Click += new System.EventHandler(this.button7_Click);
            // 
            // tbUserName
            // 
            this.tbUserName.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.tbUserName.Location = new System.Drawing.Point(153, 64);
            this.tbUserName.Name = "tbUserName";
            this.tbUserName.Size = new System.Drawing.Size(184, 25);
            this.tbUserName.TabIndex = 11;
            this.tbUserName.Text = "Имя";
            this.tbUserName.Click += new System.EventHandler(this.tbUserName_Click);
            this.tbUserName.TextChanged += new System.EventHandler(this.tbUserName_TextChanged);
            // 
            // lbChat
            // 
            this.lbChat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbChat.Font = new System.Drawing.Font("Nirmala UI", 8F, System.Drawing.FontStyle.Bold);
            this.lbChat.ForeColor = System.Drawing.Color.White;
            this.lbChat.FormattingEnabled = true;
            this.lbChat.Location = new System.Drawing.Point(1, 100);
            this.lbChat.Name = "lbChat";
            this.lbChat.Size = new System.Drawing.Size(361, 212);
            this.lbChat.TabIndex = 12;
            // 
            // tbMessage
            // 
            this.tbMessage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.tbMessage.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.tbMessage.ForeColor = System.Drawing.Color.White;
            this.tbMessage.Location = new System.Drawing.Point(1, 356);
            this.tbMessage.Multiline = true;
            this.tbMessage.Name = "tbMessage";
            this.tbMessage.Size = new System.Drawing.Size(361, 54);
            this.tbMessage.TabIndex = 13;
            this.tbMessage.Text = "Сообщение";
            this.tbMessage.Click += new System.EventHandler(this.tbMessage_Click);
            this.tbMessage.TextChanged += new System.EventHandler(this.tbMessage_TextChanged);
            this.tbMessage.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbMessage_KeyDown);
            // 
            // chatab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(362, 450);
            this.Controls.Add(this.tbMessage);
            this.Controls.Add(this.lbChat);
            this.Controls.Add(this.tbUserName);
            this.Controls.Add(this.bConnDiscon);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "chatab";
            this.Text = "chatab";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.chatab_FormClosing);
            this.Load += new System.EventHandler(this.chatab_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bConnDiscon;
        private System.Windows.Forms.TextBox tbUserName;
        private System.Windows.Forms.ListBox lbChat;
        private System.Windows.Forms.TextBox tbMessage;
    }
}