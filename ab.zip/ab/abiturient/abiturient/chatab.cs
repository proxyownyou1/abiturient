﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using abiturient.ServiceChatAbiturient;
using System.Windows.Input;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace abiturient
{
    public partial class chatab : Form , IServiceChatCallback
    {
        bool IsConnected = false;
        ServiceChatClient client;
        int ID;
        public chatab()
        {
            InitializeComponent();
        }

        private void chatab_Load(object sender, EventArgs e)
        {
            
        }

        void ConnectUser()
        {
            if (!IsConnected)
            {
                client = new ServiceChatClient(new System.ServiceModel.InstanceContext(this));
                ID =  client.Connect(tbUserName.Text);
                tbUserName.Enabled = false;
                bConnDiscon.Text = "Отключиться";
                IsConnected = true;
            }
        }
        void DisconnectUser()
        {
            if (IsConnected)
            {
                client.Disconnect(ID);
                client = null;
                tbUserName.Enabled = true;
                bConnDiscon.Text = "Подключиться";
                IsConnected = false;
            }
        }
        private void button7_Click(object sender, EventArgs e)
        {
            if (IsConnected)
            {
                DisconnectUser();
            }
            else
            {
                ConnectUser();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            
        }

        public void MsgCallBack(string msg)
        {
            lbChat.Items.Add(msg);
            int lastIndex = lbChat.Items.Count - 1;
            lbChat.TopIndex = Math.Max(0, lastIndex - (lbChat.ClientSize.Height / lbChat.ItemHeight) + 1);

        }

        private void tbMessage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if(client!=null)
                {
                    client.SendMsg(tbMessage.Text, ID);
                    tbMessage.Text=String.Empty;    
                }
                

            }
        }

        private void tbMessage_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbMessage_Click(object sender, EventArgs e)
        {
            tbMessage.Text = string.Empty;
        }

        private void tbUserName_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void tbUserName_Click(object sender, EventArgs e)
        {
            tbUserName.Text = string.Empty;
        }

        private void chatab_FormClosing(object sender, FormClosingEventArgs e)
        {
            DisconnectUser();
        }
    }
}
