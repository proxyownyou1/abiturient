﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace abiturient
{
    public partial class main : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
        (
             int nLeftRect,
             int nTopRect,
             int nRightRect,
             int nBottomRect,
             int nWidthEllipse,
            int nHeightEllipse

         );
        public main()
        {
            InitializeComponent();
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 25, 25));


        }

        private void main_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {


        }

        private void button2_Click(object sender, EventArgs e)
        {
          
            button2.BackColor = Color.FromArgb(46, 51, 73);
            MessageBox.Show("Для просмотра информации в личном кабинете авторизуйтесь", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button3_Click(object sender, EventArgs e)
        {
       
        }

        private void button4_Click(object sender, EventArgs e)
        {
         
        }

        private void button6_Click(object sender, EventArgs e)
        {

            button6.BackColor = Color.FromArgb(46, 51, 73);
            auth au = new auth();
            this.Hide();
            au.Show();
            
        }

        private void button1_Leave(object sender, EventArgs e)
        {
            
        }

        private void button2_Leave(object sender, EventArgs e)
        {
            
        }

        private void button3_Leave(object sender, EventArgs e)
        {
            
        }

        private void button4_Leave(object sender, EventArgs e)
        {

        }

        private void button6_Leave(object sender, EventArgs e)
        {
            button6.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button7_Click(object sender, EventArgs e)
        {
    
            button7.BackColor = Color.FromArgb(46, 51, 73);
            reg rg = new reg();
            this.Hide();
            rg.Show();
            
        }
    }
}
