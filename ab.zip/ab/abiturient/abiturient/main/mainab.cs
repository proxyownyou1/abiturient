﻿using abiturient.ab;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace abiturient
{
    public partial class mainab : Form
    {
        string name;
        string login;
       
        public mainab(string login)
        {
            InitializeComponent();
          
            name = login;
            label1.Text = login;
            pbar.Value = 0;
            textBox1.Visible = false;
            button7.Visible = false;


        }
       
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void mainab_Load(object sender, EventArgs e)
        {

        }
        public void ShowNotificationForm()
        {
        
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            pbar.Value += 1;
            pbar.Text = pbar.Value.ToString()+"%";
            if(pbar.Value == 89)
            {
                timer1.Enabled = false;

            }
        }

        private void pbar_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        public void ShowNotificationForm(int userID)
        {
            // Показываем другую форму (замените FormToShow на ваш класс формы уведомлений)
            settings sts = new settings(userID.ToString());

            sts.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            prosmball bal = new prosmball(login);
            this.Hide();
            bal.Show();
       
        }

        private void button3_Click(object sender, EventArgs e)
        {
            podachzayav pod = new podachzayav(login);
            this.Hide();
            pod.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            otslezayav ots = new otslezayav(login);
            this.Hide();
            ots.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //settings ots = new settings(login);
            //this.Hide();
            //ots.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            otslezayav zv = new otslezayav(login);
            this.Hide();
            zv.Show();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            textBox1.Visible = true;
            button7.Visible = true;
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.Text = null;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                // Получаем введенное имя пользователя из TextBox
                string usernameToCheck = textBox1.Text;

                // Получаем UserID для введенного пользователя
                int userId = GetUserIdByLogin(usernameToCheck);

                // Проверяем зачисление пользователя на факультет
                bool isAccepted = CheckAcceptStatus(userId);

                // Выводим MessageBox с информацией
                if (isAccepted)
                {
                    string facultyName = GetFacultyNameByUserId(userId);
                    MessageBox.Show($"Абитуриент с именем {usernameToCheck} зачислен на факультет {facultyName}.");
                }
                else
                {
                    MessageBox.Show($"Абитуриент с именем {usernameToCheck} не зачислен на факультет.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при проверке зачисления: {ex.Message}");
            }
        }
        private bool CheckAcceptStatus(int userId)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connection.con))
                {
                    conn.Open();

                    string query = "SELECT Accept FROM Applications WHERE UserID = @UserID";
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);

                        object result = command.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            return (bool)result;
                        }

                        // Если статус не найден, считаем, что абитуриент не зачислен
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при проверке статуса зачисления: {ex.Message}");
                return false;
            }
        }

        private string GetFacultyNameByUserId(int userId)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connection.con))
                {
                    conn.Open();

                    string query = "SELECT F.FacultyName " +
                                   "FROM Applications A " +
                                   "INNER JOIN Faculties F ON A.FacultyID = F.FacultyID " +
                                   "WHERE A.UserID = @UserID";

                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@UserID", userId);

                        object result = command.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            return result.ToString();
                        }

                        // Если факультет не найден, возвращаем пустую строку
                        return string.Empty;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при получении имени факультета: {ex.Message}");
                return string.Empty;
            }
        }

        private int GetUserIdByLogin(string login)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connection.con))
                {
                    conn.Open();

                    string query = "SELECT UserID FROM Users WHERE Username = @Username";
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@Username", login);

                        object result = command.ExecuteScalar();
                        if (result != null)
                        {
                            int userId = (int)result;
                            return userId;
                        }

                        // Возвращаем -1, если пользователь не найден
                        return -1;
                    }
                }
            }
            catch (Exception ex)
            {
                // Обработка ошибки, например, вывод в консоль или логирование
                Console.WriteLine($"Ошибка при получении UserID: {ex.Message}");
                return -1;
            }
        }
    }



}

