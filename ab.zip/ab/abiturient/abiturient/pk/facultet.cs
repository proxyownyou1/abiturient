﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace abiturient.pk
{
    public partial class facultet : Form
    {
        private string login;
        private SqlDataAdapter adapter;
        private DataTable dataTable;


        public facultet()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            mainpk pk = new mainpk(login);
            this.Hide();
            pk.Show();
        }

        private void facultet_Load(object sender, EventArgs e)
        {
            LoadUserDataIntoDataGridView();
        }

        private void LoadUserDataIntoDataGridView()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connection.con))
                {
                    conn.Open();

                    // Выбираем данные из таблицы Faculties
                    string query = "SELECT FacultyName, MinScore FROM Faculties";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);

                    // Создаем и заполняем DataTable
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Устанавливаем DataTable как источник данных для DataGridView
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connection.con))
                {
                    conn.Open();

                    // Создаем команды для вставки, обновления и удаления записей
                    SqlDataAdapter adapter = new SqlDataAdapter();
                    adapter.InsertCommand = new SqlCommand("INSERT INTO Faculties (FacultyName, MinScore) VALUES (@FacultyName, @MinScore)", conn);
                    adapter.UpdateCommand = new SqlCommand("UPDATE Faculties SET FacultyName = @FacultyName, MinScore = @MinScore WHERE FacultyName = @FacultyName", conn);
                    adapter.DeleteCommand = new SqlCommand("DELETE FROM Faculties WHERE FacultyName = @FacultyName", conn);

                    // Определяем параметры
                    adapter.InsertCommand.Parameters.Add("@FacultyName", SqlDbType.NVarChar, 50, "FacultyName");
                    adapter.InsertCommand.Parameters.Add("@MinScore", SqlDbType.Int, 0, "MinScore");

                    adapter.UpdateCommand.Parameters.Add("@FacultyName", SqlDbType.NVarChar, 50, "FacultyName");
                    adapter.UpdateCommand.Parameters.Add("@MinScore", SqlDbType.Int, 0, "MinScore");

                    adapter.DeleteCommand.Parameters.Add("@FacultyName", SqlDbType.NVarChar, 50, "FacultyName");

                    // Обновляем изменения в базе данных
                    adapter.Update((DataTable)dataGridView1.DataSource);
                    MessageBox.Show("Изменения сохранены.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении данных: {ex.Message}");
            }
        }
    }
}

