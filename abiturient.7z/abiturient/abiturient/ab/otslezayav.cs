﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace abiturient.ab
{
    public partial class otslezayav : Form
    {
        private string login;

        public otslezayav(string login)
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            mainab ab = new mainab(login);
            this.Hide();
            ab.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.Text = null;
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            textBox2.Text = null;
        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            textBox3.Text = null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Адрес вашего почтового ящика
                string fromEmail = "grisha.terentev.228@mail.ru";
                // Пароль от почтового ящика
         
                // Адрес, на который отправляется сообщение
                string toEmail = "grisha.terentev.228@icloud.com";
                // Тема сообщения
                string subject = "Feedback from Application";
                // Текст сообщения из TextBox
                string messageBody = textBox3.Text;

                // Создаем объект SmtpClient
                SmtpClient smtpClient = new SmtpClient("smtp.mail.ru")
                {
                    Port = 587,
                    Credentials = new NetworkCredential(fromEmail, "63fNfSwpaq17MFUQxpip"),
                    EnableSsl = true,
                };

                // Создаем объект MailMessage
                MailMessage mailMessage = new MailMessage(fromEmail, toEmail, subject, messageBody);

                // Отправляем сообщение
                smtpClient.Send(mailMessage);

                MessageBox.Show("Сообщение отправлено.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при отправке сообщения: {ex.Message}");
            }
        }
    }
}