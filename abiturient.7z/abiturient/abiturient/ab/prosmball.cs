﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace abiturient.ab
{
    public partial class prosmball : Form
    {
        private string login;

        public prosmball(string login)
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            mainab ab = new mainab(login);
            this.Hide();
            ab.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connection.con))
                {
                    conn.Open();

                    // Получаем UserID по username
                    int userId = GetUserIdByUsername(conn, textBox4.Text);
                    if (userId == -1)
                    {
                        MessageBox.Show("Пользователь с указанным именем не найден.");
                        return;
                    }

                    // Перебираем комбобоксы и текстбоксы для ввода
                    for (int i = 1; i <= 3; i++)
                    {
                        ComboBox comboBox = Controls.Find($"comboBox{i}", true).FirstOrDefault() as ComboBox;
                        TextBox textBox = Controls.Find($"textBox{i}", true).FirstOrDefault() as TextBox;

                        if (comboBox != null && textBox != null)
                        {
                            string subject = comboBox.Text;
                            if (string.IsNullOrEmpty(subject))
                            {
                                MessageBox.Show($"Выберите предмет в комбобоксе №{i}.");
                                return;
                            }

                            // Проверка на корректность ввода баллов
                            if (int.TryParse(textBox.Text, out int score))
                            {
                                // Замените "YourTableName" на фактическое имя вашей таблицы ExamScores
                                string query = $"INSERT INTO ExamScores (UserID, Subject, Score) VALUES (@UserID, @Subject, @Score)";


                                using (SqlCommand command = new SqlCommand(query, conn))
                                {
                                    command.Parameters.AddWithValue("@UserID", userId);
                                    command.Parameters.AddWithValue("@Subject", subject);
                                    command.Parameters.AddWithValue("@Score", score);

                                    command.ExecuteNonQuery();

                                    MessageBox.Show($"Баллы для предмета {subject} успешно добавлены.");
                                }
                            }
                            else
                            {
                                MessageBox.Show($"Введите корректное значение для баллов в текстбоксе №{i}.");
                                return;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении баллов: {ex.Message}");
            }
        }

        // Получение UserID по username
        private int GetUserIdByUsername(SqlConnection conn, string username)
        {
            string query = "SELECT UserID FROM Users WHERE Username = @Username";

            using (SqlCommand command = new SqlCommand(query, conn))
            {
                command.Parameters.AddWithValue("@Username", username);

                object result = command.ExecuteScalar();
                if (result != null)
                {
                    return (int)result;
                }

                return -1; // Возвращаем -1, если пользователь не найден
            }
        }
    }
}