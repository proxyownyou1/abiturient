﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace abiturient
{
    public partial class auth : Form
    {

        public auth()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void label2_Click(object sender, EventArgs e)
        {
            reg rg = new reg();
            this.Hide();
            rg.Show();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text;
            string password = textBox2.Text;

            // Хешируем введенный пользователем пароль
            string hashedPasswordInput = HashPassword(password);

            using (SqlConnection conn = new SqlConnection(connection.con))
            {
                conn.Open();

                string query = "SELECT Password, IsAdmin FROM Users WHERE Username = @Username";
                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@Username", login);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {

                           
                            string hashedPasswordFromDatabase = reader["Password"].ToString();
                            bool isAdminFromDatabase = Convert.ToBoolean(reader["IsAdmin"]);
                            if (hashedPasswordInput == hashedPasswordFromDatabase)
                            {
                                if (isAdminFromDatabase)
                                {
                                    
                                    
                                    mainpk pk = new mainpk(textBox1.Text);
                                    pk.Show();
                                    this.Close();
                                }
                                else
                                {
                                    
                                    
                                    mainab ab = new mainab(textBox1.Text);
                                    ab.Show();
                                    this.Close();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Неверный логин или пароль.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Неверный логин или пароль.");
                        }
                    }
                }
            }
        }

        
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
                byte[] hashBytes = sha256.ComputeHash(passwordBytes);

                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    builder.Append(hashBytes[i].ToString("x2"));
                }

                return builder.ToString();
            }
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.Text = null;

        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            textBox2.Text = null;
            textBox2.PasswordChar = '*';
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}