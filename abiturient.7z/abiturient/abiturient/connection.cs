﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abiturient
{
    internal class connection
    {
        public static string con = "Data Source = LAPTOP-09BJC6DC\\MSSQLSERVER01;Initial Catalog = abiturient; Integrated Security = True";
    }
}
