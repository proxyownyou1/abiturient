﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace abiturient.pk
{
    public partial class zayavki : Form
    {
        private string login;
        private DataTable dataTable;

        public zayavki()
        {
            InitializeComponent();
            dataTable = new DataTable();
            LoadApplicationsData();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            mainpk pk = new mainpk(login);
            this.Hide();
            pk.Show();
        }

        private void zayavki_Load(object sender, EventArgs e)
        {
            
            
        }

        private void LoadApplicationsData()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connection.con))
                {
                    conn.Open();

                    // Выбираем данные из таблицы applications
                    string query = "SELECT  A.ApplicationID, U.Username, F.FacultyName, A.Accept " +
                          "FROM Applications A " +
                          "INNER JOIN Users U ON A.UserID = U.UserID " +
                          "INNER JOIN Faculties F ON A.FacultyID = F.FacultyID";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);

                    // Заполняем DataTable
                    adapter.Fill(dataTable);

                    // Устанавливаем DataTable как источник данных для DataGridView
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }
        private void SaveChangesToApplications()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connection.con))
                {
                    conn.Open();

                    SqlDataAdapter adapter = new SqlDataAdapter();

                    // Создаем команду только для обновления поля Accept
                    adapter.UpdateCommand = new SqlCommand("UPDATE applications SET Accept = @Accept WHERE ApplicationID = @ApplicationID", conn);

                    // Определяем параметры
                    adapter.UpdateCommand.Parameters.Add("@Accept", SqlDbType.Bit, 0, "Accept");
                    adapter.UpdateCommand.Parameters.Add("@ApplicationID", SqlDbType.Int, 0, "ApplicationID").SourceVersion = DataRowVersion.Original;

                    // Обновляем только поле Accept в базе данных
                    adapter.Update(dataTable);
                    MessageBox.Show("Изменения сохранены.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении данных: {ex.Message}");
            }
        }

    

    private void button2_Click(object sender, EventArgs e)
        {
            SaveChangesToApplications();
        }
    }
}
